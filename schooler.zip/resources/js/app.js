require('./bootstrap');
const feather = require('feather-icons')

feather.replace();