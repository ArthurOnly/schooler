

<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 font-mono">
  <div class="mb-4">
      <a href="<?php echo e(route('users.create')); ?>" class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Criar nova</a>
  </div>
  <div class="w-full mb-8 overflow-hidden rounded-lg shadow-lg">
    <div class="w-full overflow-x-auto">
      <table class="w-full">
        <thead>
          <tr class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
            <th class="px-4 py-3">Nome</th>
            <th class="px-4 py-3">Email</th>
            <th class="px-4 py-3">Tipo</th>
            <th class="px-4 py-3">Ações</th>
          </tr>
        </thead>
        <tbody class="bg-white">
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-gray-700">
              <td class="px-4 py-3 text-ms border"><?php echo e($user->name); ?></td>
              <td class="px-4 py-3 text-ms border"><?php echo e($user->email); ?></td>
              <td class="px-4 py-3 text-ms border">
                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none bg-green-700 text-white rounded"><?php echo e($role); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td>
              <td class="px-4 py-3 text-ms border">
              <a href="<?php echo e(route('users.show', $user->id)); ?>">Visualizar</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php echo e($users->links()); ?>     
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/users/index.blade.php ENDPATH**/ ?>