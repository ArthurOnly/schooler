

<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto p-6 font-mono">
        <?php if(session()->has('success')): ?>
            <h2 class="bg-green-700 p-4 mb-4"><?php echo e(session('success')['message']); ?></h2>
        <?php endif; ?>
        <div class="mb-4 flex justify-between">
            <form class="flex gap-4" action="<?php echo e(route('users.index')); ?>" method="GET">
                <div class="flex flex-col gap-2">
                    <label>Nome</label>
                    <input type="text" name="name" value=<?php echo e(request()->query('name', '')); ?>></input>
                </div>
                <div class="flex flex-col gap-2">
                    <label>Tipo</label>
                    <select name='type' class="p-2">
                        <option selected value>Todos</option>
                        <option <?php if(request()->query('type') == 'student'): ?> selected <?php endif; ?> value="student">Aluno</option>
                        <option <?php if(request()->query('type') == 'teacher'): ?> selected <?php endif; ?> value="teacher">Professor</option>
                        <option <?php if(request()->query('type') == 'secretary'): ?> selected <?php endif; ?> value="secretary">Secretário</option>
                        <option <?php if(request()->query('type') == 'coordinator'): ?> selected <?php endif; ?> value="coordinator">Coordenador</option>
                        <option <?php if(request()->query('type') == 'financial'): ?> selected <?php endif; ?> value="financial">Financeiro</option>
                        <option <?php if(request()->query('type') == 'director'): ?> selected <?php endif; ?> value="director">Diretor</option>
                    </select>
                </div>
                <button type="submit" class="bg-green-700 p-2 text-white h-auto mt-auto">Buscar</button>
            </form>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create users')): ?>
            <a href="<?php echo e(route('users.create')); ?>" class="bg-green-700 p-2 text-white mb-2 max-w-lg h-full my-auto">Criar
                novo usuário</a>
            <?php endif; ?>
        </div>
        <div class="w-full mb-8 overflow-hidden rounded-lg shadow-lg">
            <div class="w-full overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr
                            class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
                            <th class="px-4 py-3">Nome</th>
                            <th class="px-4 py-3">Email</th>
                            <th class="px-4 py-3">Tipo</th>
                            <th class="px-4 py-3">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700">
                                <td class="px-4 py-3 text-ms border"><?php echo e($user->name); ?></td>
                                <td class="px-4 py-3 text-ms border"><?php echo e($user->email); ?></td>
                                <td class="px-4 py-3 text-ms border">
                                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span
                                            class="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none bg-green-700 text-white rounded"><?php echo e($role); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td class="px-4 py-3 text-ms border">
                                    <a href="<?php echo e(route('users.show', $user->id)); ?>">Visualizar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo e($users->links()); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/users/index.blade.php ENDPATH**/ ?>