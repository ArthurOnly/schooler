

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
    <?php if(auth()->check() && auth()->user()->hasAnyRole('financial')): ?>
    <div class="flex justify-between">
    <span></span>
    <div class="flex gap-4">
        <a href="<?php echo e(route('payments.edit', $payment->id)); ?>" class="flex"><i data-feather="edit"></i><span class="ml-2">Editar</span> </a>
        <form method="POST" action=<?php echo e(route('payments.delete', $payment->id)); ?> onsubmit="return confirm('Você tem certeza que quer deletar o boleto?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="flex text-red-700"><i data-feather="user-minus"></i><span class="ml-2">Deletar</span> </a>
        </form>
    </div>
  </div>
  <?php endif; ?>
  <form>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Value</label>
                <input required disabled type="text" name="value" value="<?php echo e(old('value', $payment->value)); ?>"/>
            </div>
            <div class="flex flex-col">
                <label class="mb-2" for="students">Aluno</label>
                <input required disabled type="text" name="value" value="<?php echo e(old('value', $payment->user->name)); ?>"/>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Mês de referência</label>
                <input required disabled type="month" name='reference' value="<?php echo e(old('reference', $payment->reference)); ?>"/>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Pago</label>
                <?php if($payment->paid): ?> 
                    <span class="p-2 rounded bg-green-700 w-max text-white">Pago</span>
                <?php else: ?>
                    <span class="p-2 rounded bg-red-700 w-max text-white">Não pago</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Boleto</label>
                <a type="download" href="<?php echo e(asset('storage/'.$payment->file)); ?>" target="_blank">Download do boleto</a>
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin-scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.full.min.js" integrity="sha512-RtZU3AyMVArmHLiW0suEZ9McadTdegwbgtiQl5Qqo9kunkVg1ofwueXD8/8wv3Af8jkME3DDe3yLfR8HSJfT2g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $(document).ready(function() {
            $('#students').select2();
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/payments/show.blade.php ENDPATH**/ ?>