

<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto p-6 bg-white">
        <div class="flex justify-between">
            <h1 class="text-2xl mb-8"><?php echo e($user->name); ?></h1>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
            <div class="flex gap-4">
                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="flex"><i data-feather="edit"></i><span
                        class="ml-2">Editar</span> </a>
                <form method="POST" action=<?php echo e(route('users.delete', $user->id)); ?>

                    onsubmit="return confirm('Você tem certeza que quer deletar o usuário?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="flex text-red-700"><i data-feather="user-minus"></i><span
                            class="ml-2">Deletar</span> </a>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <form>
            <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
                <div class="flex flex-col">
                    <label class="mb-2">Nome</label>
                    <input disabled type="text" name="name" value="<?php echo e($user->name); ?>" />
                </div>
                <div class="flex flex-col">
                    <label class="mb-2">Email</label>
                    <input disabled type="email" name="email" value="<?php echo e($user->email); ?>" />
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
                <div class="flex flex-col">
                    <label class="mb-2">Função</label>
                    <select disabled name="role" multiple>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($user->hasRole($role)): ?>
                                selected
                        <?php endif; ?>
                        >
                        <?php echo e($role); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <?php if($user->hasRole('student')): ?>
                <div class="grid grid-cols-1 md:grid-cols-1 mt-4 gap-4">
                    <div class="w-full mb-8 overflow-hidden rounded-lg shadow-lg">
                        <label class="mb-2">Boletos</label>
                        <div class="w-full overflow-x-auto">
                            <table class="w-full">
                                <thead>
                                    <tr
                                        class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
                                        <th class="px-4 py-3">Valor</th>
                                        <th class="px-4 py-3">Mês de referência</th>
                                        <th class="px-4 py-3">Pago</th>
                                        <th class="px-4 py-3">Ações</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white">
                                    <?php $__currentLoopData = $user->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-gray-700">
                                            <td class="px-4 py-3 text-ms border"><?php echo e($payment->value); ?></td>
                                            <td class="px-4 py-3 text-ms border"><?php echo e($payment->reference); ?></td>
                                            <td class="px-4 py-3 text-ms border">
                                                <?php if($payment->paid): ?>
                                                    <span class="p-2 rounded bg-green-700 w-max text-white">Pago</span>
                                                <?php else: ?>
                                                    <span class="p-2 rounded bg-red-700 w-max text-white">Não pago</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="px-4 py-3 text-ms border">
                                                <a href="<?php echo e(route('payments.show', $payment->id)); ?>">Visualizar</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/users/show.blade.php ENDPATH**/ ?>