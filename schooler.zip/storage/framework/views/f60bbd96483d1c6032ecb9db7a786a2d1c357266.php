

<?php $__env->startSection('title', 'Classes'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <form class="container mx-auto p-6 font-mono" action="<?php echo e(route('classes.aulas.update', $class->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
            <div class="w-full mb-8 overflow-hidden rounded-lg">
                <div class="w-full overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr
                                class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
                                <th class="px-4 py-3">Nome do aluno</th>
                                <th class="px-4 py-3">Faltas</th>
                                <th class="px-4 py-3">Nota</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white">
                            <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-gray-700">
                                    <td class="px-4 py-3 text-ms border"><?php echo e($student->user->name); ?></td>
                                    <td class="px-4 py-3 text-ms border"><input type="number" class="border"
                                            name="students[<?php echo e($student->id); ?>][absences]" value="<?php echo e($student->absences); ?>"></input></td>
                                    <td class="px-4 py-3 text-ms border"><input type="number" class="border"
                                            name="students[<?php echo e($student->id); ?>][score]" value="<?php echo e($student->score); ?>"></input></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notas classroom')): ?>
            <div class="mb-4">
                <button type='submit'
                    class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Atualizar</button>
            </div>
            <?php endif; ?>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/classes/aulas.blade.php ENDPATH**/ ?>