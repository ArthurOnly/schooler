

<?php $__env->startSection('title', 'Polo'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto p-6 bg-white">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit polo')): ?>
            <div class="flex justify-between">
                <h1 class="text-2xl mb-8"><?php echo e($polo->name); ?></h1>
                <div class="flex gap-4">
                    <a href="<?php echo e(route('polo.edit', $polo->id)); ?>" class="flex"><i data-feather="edit"></i><span
                            class="ml-2">Editar</span> </a>
                    <form method="POST" action=<?php echo e(route('polo.destroy', $polo->id)); ?>

                        onsubmit="return confirm('Você tem certeza que quer deletar o usuário?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="flex text-red-700"><i data-feather="user-minus"></i><span
                                class="ml-2">Deletar</span> </a>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <form>
            <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
                <div class="flex flex-col">
                    <label class="mb-2">Nome</label>
                    <input disabled type="text" name="name" value="<?php echo e($polo->name); ?>" />
                </div>
            </div>
        </form>
    </section>
    <section class="container mx-auto p-6 bg-white mt-4">
        <h2 class="mb-2">Turmas</h2>
        <div class="w-full mb-8 overflow-hidden rounded-lg">
            <div class="w-full overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr
                            class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
                            <th class="px-4 py-3">Nome</th>
                            <th class="px-4 py-3">Curso</th>
                            <th class="px-4 py-3">Professor</th>
                            <th class="px-4 py-3">Estudantes</th>
                            <th class="px-4 py-3">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <?php $__currentLoopData = $polo->classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700">
                                <td class="px-4 py-3 text-ms border"><?php echo e($class->name); ?></td>
                                <td class="px-4 py-3 text-ms border"><?php echo e($class->course); ?></td>
                                <td class="px-4 py-3 text-ms border"><?php echo e($class->polo->name); ?></td>
                                <td class="px-4 py-3 text-ms border"><?php echo e($class->teacher->name); ?></td>
                                <td class="px-4 py-3 text-ms border"><?php echo e(sizeOf($class->students)); ?></td>
                                <td class="px-4 py-3 text-ms border">
                                    <a href="<?php echo e(route('classes.show', $class->id)); ?>">Visualizar</a>
                                    <?php if(auth()->check() && auth()->user()->hasAnyRole('director|coordinator|secretary|teacher')): ?>
                                        <p class="inline"> | </p>
                                        <a href="<?php echo e(route('classes.aulas', $class->id)); ?>">Gerenciar</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/polo/show.blade.php ENDPATH**/ ?>