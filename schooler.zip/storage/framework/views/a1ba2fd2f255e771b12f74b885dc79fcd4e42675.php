

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto p-6 bg-white">
        <div class="flex justify-between">
            <h1 class="text-2xl mb-8"><?php echo e($polo->name); ?></h1>
            <div class="flex gap-4">
                <a href="<?php echo e(route('polo.edit', $polo->id)); ?>" class="flex"><i data-feather="edit"></i><span
                        class="ml-2">Editar</span> </a>
                <form method="POST" action=<?php echo e(route('polo.destroy', $polo->id)); ?>

                    onsubmit="return confirm('Você tem certeza que quer deletar o usuário?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="flex text-red-700"><i data-feather="user-minus"></i><span
                            class="ml-2">Deletar</span> </a>
                </form>
            </div>
        </div>
        <form>
            <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
                <div class="flex flex-col">
                    <label class="mb-2">Nome</label>
                    <input disabled type="text" name="name" value="<?php echo e($polo->name); ?>" />
                </div>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/polo/show.blade.php ENDPATH**/ ?>