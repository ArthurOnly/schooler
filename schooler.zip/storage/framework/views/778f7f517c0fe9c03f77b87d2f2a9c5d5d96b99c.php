

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
  <form method="POST" action="<?php echo e(route('users.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Nome</label>
                <input required type="text" name="name" value="<?php echo e(old('name')); ?>"/>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Email</label>
                <input required type="email" name="email" value="<?php echo e(old('email')); ?>"/>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Função</label>
                <select required name="roles[]" multiple>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option 
                         value=<?php echo e($role); ?>

                         >
                         <?php echo e($role); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Polo</label>
                <select required name="polo_id">
                    <?php $__currentLoopData = $polos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option 
                         value=<?php echo e($polo->id); ?>

                         >
                         <?php echo e($polo->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <button type="submit" class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Atualizar</button>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/users/create.blade.php ENDPATH**/ ?>