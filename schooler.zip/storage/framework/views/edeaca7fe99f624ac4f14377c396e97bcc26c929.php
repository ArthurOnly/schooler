

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
  <div class="flex justify-between">
    <h1 class="text-2xl mb-8"><?php echo e($polo->name); ?></h1>
    <div class="flex gap-4">
        <a href="<?php echo e(route('polo.edit', $polo->id)); ?>" class="flex"><i data-feather="edit"></i><span class="ml-2">Editar</span> </a>
        <a href="#" class="flex text-red-700"><i data-feather="user-minus"></i><span class="ml-2">Deletar</span> </a>
    </div>
  </div>
  <form method="POST" action="<?php echo e(route('polo.update', $polo->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Nome</label>
                <input type="text" name="name" value="<?php echo e($polo->name); ?>"/>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <button type="submit" class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Atualizar</button>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/polo/edit.blade.php ENDPATH**/ ?>