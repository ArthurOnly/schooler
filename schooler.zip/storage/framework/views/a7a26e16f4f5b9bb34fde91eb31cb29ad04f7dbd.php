

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
  <form method="POST" action="<?php echo e(route('classes.update', $class->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Nome</label>
                <input type="text" name="name" value="<?php echo e(old('name', $class->name)); ?>"/>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Professor</label>
                </select>
                <select class="p-2" name="teacher_id" value="<?php echo e(old('teacher_id', $class->teacher->id)); ?>">
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option 
                         value=<?php echo e($teacher->id); ?>

                         <?php if($teacher->id == $class->teacher->id): ?>
                            selected
                         <?php endif; ?>
                         >
                         <?php echo e($teacher->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Alunos</label>
                <select name="students[]" multiple>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option 
                            <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classStudents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($student->id == $classStudents->user->id): ?>
                                    selected
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         value="<?php echo e($student->id); ?>"
                         >
                         <?php echo e($student->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <button type="submit" class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Atualizar</button>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/classes/edit.blade.php ENDPATH**/ ?>