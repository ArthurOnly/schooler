

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
        <section>
            <div class="container mx-auto p-6 bg-white">
                <div class="mb-8">
                    <h1 class="text-3xl">Minhas turmas</h1>
                </div>
                <div class="flex">
                    <?php $__currentLoopData = auth()->user()->classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex p-4 flex-col border">
                            <h2 class="text-2xl mb-2"><?php echo e($classroom->name); ?></h2>
                            <p class="text-lg">Nota:
                                <?php $__currentLoopData = $classroom->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($student->student_id == auth()->user()->id): ?>
                                        <?php echo e($student->score ? $student->score : 'Não lançado'); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </h2>
                            <p class="text-lg">Faltas:
                                <?php $__currentLoopData = $classroom->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($student->student_id == auth()->user()->id): ?>
                                        <?php echo e($student->absences); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                            <a class="text-blue-700 mt-2" href="<?php echo e(route('classes.show', $classroom->id)); ?>">Ver mais</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <section>
            <div class="container mx-auto p-6 bg-white mt-8">
                <div class="mb-8">
                    <h1 class="text-3xl">Meus boletos</h1>
                </div>
                <div class="w-full overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr
                                class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
                                <th class="px-4 py-3">Valor</th>
                                <th class="px-4 py-3">Mês de referência</th>
                                <th class="px-4 py-3">Pago</th>
                                <th class="px-4 py-3">Ações</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white">
                            <?php if(count(auth()->user()->payments)>0): ?>
                                <?php $__currentLoopData = auth()->user()->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-gray-700">
                                        <td class="px-4 py-3 text-ms border"><?php echo e($payment->value); ?></td>
                                        <td class="px-4 py-3 text-ms border"><?php echo e($payment->reference); ?></td>
                                        <td class="px-4 py-3 text-ms border">
                                            <?php if($payment->paid): ?>
                                                <span class="p-2 rounded bg-green-700 w-max text-white">Pago</span>
                                            <?php else: ?>
                                                <span class="p-2 rounded bg-red-700 w-max text-white">Não pago</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3 text-ms border">
                                            <a href="<?php echo e(route('payments.show', $payment->id)); ?>">Visualizar</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="text-gray-700">
                                    <td colspan="4" class="px-4 py-3 text-ms border">Nenhum boleto cadastrado</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('teacher')): ?>
        <section>
            <div class="container mx-auto p-6 bg-white mt-8">
                <div class="mb-8">
                    <h1 class="text-3xl">Minhas turmas</h1>
                </div>
                <div class="flex">
                    <?php $__currentLoopData = auth()->user()->classrooms_teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex p-4 flex-col border">
                            <h2 class="text-2xl mb-2"><?php echo e($classroom->name); ?></h2>
                            <a class="text-blue-700 mt-2" href="<?php echo e(route('classes.aulas', $classroom->id)); ?>">Gerenciar</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/dashboard.blade.php ENDPATH**/ ?>