

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
  <div class="flex justify-between">
    <h1 class="text-2xl mb-8"><?php echo e($class->name); ?></h1>
    <div class="flex gap-4">
        <?php if(auth()->check() && auth()->user()->hasAnyRole('director|coordinator')): ?>
        <a href="<?php echo e(route('classes.edit', $class->id)); ?>" class="flex"><i data-feather="edit"></i><span class="ml-2">Editar</span> </a>
        <form method="POST" action=<?php echo e(route('classes.delete', $class->id)); ?> onsubmit="return confirm('Você tem certeza que quer deletar a classe?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="flex text-red-700"><i data-feather="user-minus"></i><span class="ml-2">Deletar</span> </a>
        </form>
        <?php endif; ?>
    </div>
  </div>
  <form>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Nome</label>
                <p><?php echo e($class->name); ?></p>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Professor</label>
                <a href="<?php echo e(route('users.show', $class->teacher->id)); ?>">
                        <span class="flex gap-2 mb-2"> <i data-feather="eye"></i><?php echo e($class->teacher->name); ?> <span>
                </a>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Alunos</label>
                <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('users.show', $student->user->id)); ?>">
                        <span class="flex gap-2 mb-2"> <i data-feather="eye"></i><?php echo e($student->user->name); ?> <span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/classes/show.blade.php ENDPATH**/ ?>