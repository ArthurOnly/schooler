

<?php $__env->startSection('title', 'Classes'); ?>

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
  <div class="flex justify-between">
    <h1 class="text-2xl mb-8"><?php echo e($class->name); ?></h1>
    <div class="flex gap-4">
        <?php if(auth()->check() && auth()->user()->hasAnyRole('director|coordinator')): ?>
        <form method="POST" action=<?php echo e(route('classes.store', $class->id)); ?>>
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <input type='hidden' name='name' value='<?php echo e($class->name); ?>-<?php echo e(uniqid()); ?>'>
            <input type='hidden' name='teacher_id' value='<?php echo e($class->teacher_id); ?>'>
            <input type='hidden' name='course' value='<?php echo e($class->course); ?>'>
            <input type='hidden' name='polo_id' value='<?php echo e($class->polo_id); ?>'>
            <select hidden id='students' name="students[]" multiple class="py-4">
                <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                        value="<?php echo e($student->id); ?>"
                        selected
                        >
                        <?php echo e($student->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="flex"><i data-feather="copy"></i><span class="ml-2">Duplicar</span></button>
        </form>
        <a href="<?php echo e(route('classes.edit', $class->id)); ?>" class="flex"><i data-feather="edit"></i><span class="ml-2">Editar</span> </a>
        <form method="POST" action=<?php echo e(route('classes.delete', $class->id)); ?> onsubmit="return confirm('Você tem certeza que quer deletar a classe?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="flex text-red-700"><i data-feather="user-minus"></i><span class="ml-2">Deletar</span> </a>
        </form>
        <?php endif; ?>
    </div>
  </div>
  <form>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Nome</label>
                <p><?php echo e($class->name); ?></p>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Curso</label>
                <p><?php echo e($class->course); ?></p>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Professor</label>
                <a href="<?php echo e(route('users.show', $class->teacher->id)); ?>">
                        <span class="flex gap-2 mb-2"> <i data-feather="eye"></i><?php echo e($class->teacher->name); ?> <span>
                </a>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Alunos</label>
                <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('users.show', $student->user->id)); ?>">
                        <span class="flex gap-2 mb-2"> <i data-feather="eye"></i><?php echo e($student->user->name); ?> <span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Polo</label>
                <p><?php echo e($class->polo->name); ?></p>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Criado em</label>
                <p><?php echo e($class->created_at); ?></p>
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/classes/show.blade.php ENDPATH**/ ?>