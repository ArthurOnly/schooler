

<?php $__env->startSection('title', 'Pagamentos'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto p-6 font-mono">
        <div class="mb-4 flex justify-between">
            <form class="flex gap-4" action="<?php echo e(route('payments.index')); ?>" method="GET">
                <div class="flex flex-col gap-2">
                    <label>Nome</label>
                    <input type="text" name="name" value=<?php echo e(request()->query('name', '')); ?>></input>
                </div>
                <button type="submit" class="bg-green-700 p-2 text-white h-auto mt-auto">Buscar</button>
            </form>
            <div class="mb-4 flex justify-between items-center">
                <a href="<?php echo e(route('payments.create')); ?>" class="bg-green-700 p-2 text-white w-max mb-2 max-w-lg mr-2">Criar
                    novo boleto</a>
                <a href="<?php echo e(route('payments.csv')); ?>" download
                    class="border-2 border-green-700 w-max p-2 text-green-700 mb-2 max-w-lg">Gerar relatório</a>
            </div>
        </div>
        <div class="w-full mb-8 overflow-hidden rounded-lg shadow-lg">
            <div class="w-full overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr
                            class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
                            <th class="px-4 py-3">Usuário</th>
                            <th class="px-4 py-3">Pagos/Existentes</th>
                            <th class="px-4 py-3">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700">
                                <td class="px-4 py-3 text-ms border"><?php echo e($user->name); ?></td>
                                <td class="px-4 py-3 text-ms border">
                                    <?php if($user->in_day): ?>
                                        <span class="p-2 rounded bg-green-700 w-max text-white">Em dia</span>
                                    <?php else: ?>
                                        <span class="p-2 rounded bg-red-700 w-max text-white">Em atraso</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-ms border">
                                    <a href="<?php echo e(route('users.show', $user->id)); ?>">Visualizar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo e($users->links()); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/payments/index.blade.php ENDPATH**/ ?>