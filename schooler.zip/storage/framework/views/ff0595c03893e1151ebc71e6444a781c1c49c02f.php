

<?php $__env->startSection('title', 'Polo'); ?>

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 font-mono">
  <div class="mb-4">
      <a href="<?php echo e(route('polo.create')); ?>" class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Criar novo</a>
  </div>
  <div class="w-full mb-8 overflow-hidden rounded-lg shadow-lg">
    <div class="w-full overflow-x-auto">
      <table class="w-full">
        <thead>
          <tr class="text-md font-semibold tracking-wide text-left text-gray-900 bg-gray-100 uppercase border-b border-gray-600">
            <th class="px-4 py-3">Nome</th>
            <th class="px-4 py-3">Ações</th>
          </tr>
        </thead>
        <tbody class="bg-white">
          <?php $__currentLoopData = $polos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-gray-700">
              <td class="px-4 py-3 text-ms border"><?php echo e($polo->name); ?></td>
              <td class="px-4 py-3 text-ms border">
              <a href="<?php echo e(route('polo.show', $polo->id)); ?>">Visualizar</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php echo e($polos->links()); ?>     
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/polo/index.blade.php ENDPATH**/ ?>