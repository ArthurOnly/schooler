

<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 bg-white">
  <div class="flex justify-between">
    <h1 class="text-2xl mb-8"><?php echo e($user->name); ?></h1>
    <div class="flex gap-4">
        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="flex"><i data-feather="edit"></i><span class="ml-2">Editar</span> </a>
        <a href="#" class="flex text-red-700"><i data-feather="user-minus"></i><span class="ml-2">Deletar</span> </a>
    </div>
  </div>
  <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Nome</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>"/>
            </div>
            <div class="flex flex-col">
                <label class="mb-2">Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>"/>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <div class="flex flex-col">
                <label class="mb-2">Função</label>
                <select name="roles[]" multiple>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option 
                         <?php if($user->hasRole($role)): ?>
                         selected
                         <?php endif; ?>
                         value=<?php echo e($role); ?>

                         >
                         <?php echo e($role); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 mt-4 gap-4">
            <button type="submit" class="bg-green-700 p-2 text-white w-full mb-2 max-w-lg">Atualizar</button>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/users/edit.blade.php ENDPATH**/ ?>