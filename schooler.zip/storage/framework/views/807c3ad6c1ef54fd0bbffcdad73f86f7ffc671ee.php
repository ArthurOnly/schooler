<html>
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
   <?php echo notifyCss(); ?>
</head>

<body>
   <div class="h-screen w-screen flex bg-gray-200">
      <?php echo $__env->yieldContent('content'); ?>
   </div>

   <!--Notification-->
   <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
   <?php echo notifyJs(); ?>
</body>
</html><?php /**PATH C:\Users\arthu\Desktop\Programação\schooler\resources\views/layouts/guest.blade.php ENDPATH**/ ?>